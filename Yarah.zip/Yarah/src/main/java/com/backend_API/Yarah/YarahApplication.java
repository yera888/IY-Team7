package com.backend_API.Yarah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YarahApplication {

	public static void main(String[] args) {
		SpringApplication.run(YarahApplication.class, args);
	}

}

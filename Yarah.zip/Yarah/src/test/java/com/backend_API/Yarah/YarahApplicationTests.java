package com.backend_API.Yarah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YarahApplicationTests {

	@Test
	void contextLoads() {
	}

}
